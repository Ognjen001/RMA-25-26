package com.example.pozdravnaporuka

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editTextName = findViewById<EditText>(R.id.editTextName)
        val buttonGreet = findViewById<Button>(R.id.buttonGreet)
        val buttonNext = findViewById<Button>(R.id.buttonNext)
        val textViewResult = findViewById<TextView>(R.id.textViewResult)
        val imageViewLogo = findViewById<ImageView>(R.id.imageViewLogo)

        buttonGreet.setOnClickListener {
            val name = editTextName.text.toString().trim()

            if (name.isEmpty()) {
                Toast.makeText(this, "Unesite ime!", Toast.LENGTH_SHORT).show()
            } else {
                val message = "Zdravo, $name!"
                textViewResult.text = message
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                imageViewLogo.animate().rotationBy(360f).setDuration(1000).start()

            }
            buttonNext.setOnClickListener {
                val name = editTextName.text.toString().trim()

                if (name.isEmpty()) {
                    Toast.makeText(this, "Unesite ime pre prelaska!", Toast.LENGTH_SHORT).show()
                } else {
                    val intent = Intent(this, SecondActivity::class.java)
                    intent.putExtra("USER_NAME", name)
                    startActivity(intent)
                }
            }

        }
    }
}
