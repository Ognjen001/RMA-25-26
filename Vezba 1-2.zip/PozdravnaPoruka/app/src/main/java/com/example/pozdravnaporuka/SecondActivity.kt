package com.example.pozdravnaporuka

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val textViewWelcome = findViewById<TextView>(R.id.textViewWelcome)
        val buttonBack = findViewById<Button>(R.id.buttonBack)
        val userName = intent.getStringExtra("USER_NAME")

        textViewWelcome.text = "Dobrodošao, $userName!"

        buttonBack.setOnClickListener {
            finish()
        }
    }
}
