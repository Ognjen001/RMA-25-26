package com.example.vezba8

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class QuizActivity : AppCompatActivity() {

    private lateinit var questionText: TextView
    private lateinit var option1: RadioButton
    private lateinit var option2: RadioButton
    private lateinit var option3: RadioButton
    private lateinit var option4: RadioButton
    private lateinit var optionsGroup: RadioGroup
    private lateinit var nextBtn: Button

    private var currentQuestionIndex = 0
    private var score = 0

    private val questions = listOf(
        Question(
            "Koji je glavni programski jezik za Android?",
            listOf("Java", "Kotlin", "Python", "C++"),
            1
        ),
        Question(
            "Šta znači OOP?",
            listOf(
                "Object Oriented Programming",
                "Open Object Protocol",
                "Optional Object Package",
                "None"
            ),
            0
        ),
        Question(
            "Koji layout se najčešće koristi?",
            listOf("LinearLayout", "TableLayout", "GridLayout", "FrameLayout"),
            0
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)

        // findViewById za sve view-e
        questionText = findViewById(R.id.questionText)
        option1 = findViewById(R.id.option1)
        option2 = findViewById(R.id.option2)
        option3 = findViewById(R.id.option3)
        option4 = findViewById(R.id.option4)
        optionsGroup = findViewById(R.id.optionsGroup)
        nextBtn = findViewById(R.id.nextBtn)

        loadQuestion()

        nextBtn.setOnClickListener {
            checkAnswer()
            currentQuestionIndex++

            if (currentQuestionIndex < questions.size) {
                loadQuestion()
            } else {
                val intent = Intent(this, ResultActivity::class.java)
                intent.putExtra("SCORE", score)
                startActivity(intent)
                finish()
            }
        }
    }

    private fun loadQuestion() {
        val q = questions[currentQuestionIndex]
        questionText.text = q.questionText
        option1.text = q.options[0]
        option2.text = q.options[1]
        option3.text = q.options[2]
        option4.text = q.options[3]
        optionsGroup.clearCheck()
    }

    private fun checkAnswer() {
        val selectedId = optionsGroup.checkedRadioButtonId
        if (selectedId != -1) {
            val selectedIndex = when (selectedId) {
                R.id.option1 -> 0
                R.id.option2 -> 1
                R.id.option3 -> 2
                R.id.option4 -> 3
                else -> -1
            }
            if (selectedIndex == questions[currentQuestionIndex].correctAnswerIndex) {
                score += 10
            }
        }
    }
}
