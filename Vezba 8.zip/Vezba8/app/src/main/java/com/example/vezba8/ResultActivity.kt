package com.example.vezba8

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ResultActivity : AppCompatActivity() {

    private lateinit var resultText: TextView
    private lateinit var restartBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        // findViewById za TextView i Button
        resultText = findViewById(R.id.resultText)
        restartBtn = findViewById(R.id.restartBtn)

        val score = intent.getIntExtra("SCORE", 0)
        resultText.text = "Osvojili ste $score poena 🎉"

        restartBtn.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}
