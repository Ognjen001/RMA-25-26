package com.example.vezba8

data class Question(
    val questionText: String,
    val options: List<String>,
    val correctAnswerIndex: Int
)
