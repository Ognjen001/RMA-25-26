package com.example.notes

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class AddNoteActivity : AppCompatActivity() {

    private var position: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_note)

        val editText: EditText = findViewById(R.id.editTextNote)
        val btnSave: Button = findViewById(R.id.btnSave)

        // Provera da li je edit
        val note = intent.getStringExtra("note")
        position = intent.getIntExtra("position", -1)
        if (note != null) {
            editText.setText(note)
        }

        btnSave.setOnClickListener {
            val newNote = editText.text.toString()
            val intent = Intent()
            intent.putExtra("note", newNote)
            intent.putExtra("position", position)
            setResult(RESULT_OK, intent)
            finish()
        }
    }
}
