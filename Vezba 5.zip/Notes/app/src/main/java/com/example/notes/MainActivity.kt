package com.example.notes
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val notes = ArrayList<String>()
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val listView: ListView = findViewById(R.id.listViewNotes)
        val btnAdd: Button = findViewById(R.id.btnAddNote)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, notes)
        listView.adapter = adapter

        // Dodavanje nove beleške
        btnAdd.setOnClickListener {
            val intent = Intent(this, AddNoteActivity::class.java)
            startActivityForResult(intent, 1)
        }

        // Klik na item -> izmena
        listView.setOnItemClickListener { _, _, position, _ ->
            val intent = Intent(this, AddNoteActivity::class.java)
            intent.putExtra("note", notes[position])
            intent.putExtra("position", position)
            startActivityForResult(intent, 2) // requestCode 2 = edit
        }

        // Dug klik -> brisanje
        listView.setOnItemLongClickListener { _, _, position, _ ->
            notes.removeAt(position)
            adapter.notifyDataSetChanged()
            true
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && data != null) {
            val note = data.getStringExtra("note")
            val position = data.getIntExtra("position", -1)

            if (note != null) {
                if (requestCode == 1) {
                    // dodavanje
                    notes.add(note)
                } else if (requestCode == 2 && position != -1) {
                    // izmena
                    notes[position] = note
                }
                adapter.notifyDataSetChanged()
            }
        }
    }
}
