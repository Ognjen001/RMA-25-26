package com.example.vezba7

import android.os.Bundle
import android.os.Handler
import android.widget.Button
import android.widget.GridLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var gridLayout: GridLayout
    private lateinit var tvTimer: TextView
    private val cards = ArrayList<Int>()
    private val buttons = ArrayList<Button>()
    private var firstCardIndex: Int? = null
    private var isBusy = false
    private var seconds = 0
    private val handler = Handler()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        gridLayout = findViewById(R.id.gridLayout)
        tvTimer = findViewById(R.id.tvTimer)

        setupCards()
        setupGrid()
        startTimer()
    }

    private fun setupCards() {
        // 8 различитих "слiка" представљене бројевима 1-8, сваки два пута
        for (i in 1..8) {
            cards.add(i)
            cards.add(i)
        }
        cards.shuffle()
    }

    private fun setupGrid() {
        for (i in 0 until 16) {
            val button = Button(this)
            button.text = "?"
            button.textSize = 24f
            button.setOnClickListener { onCardClicked(i) }
            buttons.add(button)
            gridLayout.addView(button)
        }
    }

    private fun onCardClicked(index: Int) {
        if (isBusy || buttons[index].text != "?") return

        buttons[index].text = cards[index].toString()

        if (firstCardIndex == null) {
            firstCardIndex = index
        } else {
            val secondCardIndex = index
            if (cards[firstCardIndex!!] == cards[secondCardIndex]) {
                // Пар је пронађен, остају откривени
                firstCardIndex = null
                checkGameFinished()
            } else {
                // Није пар, окрени назад после 1 секунде
                isBusy = true
                handler.postDelayed({
                    buttons[firstCardIndex!!].text = "?"
                    buttons[secondCardIndex].text = "?"
                    firstCardIndex = null
                    isBusy = false
                    checkGameFinished()
                }, 1000)
            }
        }
    }

    private fun startTimer() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                seconds++
                tvTimer.text = "Time: ${seconds}s"
                handler.postDelayed(this, 1000)
            }
        }, 1000)
    }

    private fun checkGameFinished() {
        val allMatched = buttons.all { it.text != "?" }
        if (allMatched) {
            handler.removeCallbacksAndMessages(null) // зауставља Timer
            Toast.makeText(this, "Честитам! Игра завршена у $seconds секунди", Toast.LENGTH_LONG).show()
        }
    }
}
