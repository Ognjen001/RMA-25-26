package com.example.firebaseapp

data class User(
    var uid: String? = null,
    var ime: String? = null,
    var username: String? = null,
    var email: String? = null,
    var role: String? = "user"
)
