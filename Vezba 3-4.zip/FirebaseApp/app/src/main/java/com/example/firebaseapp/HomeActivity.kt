package com.example.firebaseapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class HomeActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val welcomeText = findViewById<TextView>(R.id.welcomeText)
        val logoutButton = findViewById<Button>(R.id.logoutButton)
        val adminButton = findViewById<Button>(R.id.adminButton)

        auth = FirebaseAuth.getInstance()
        val userId = auth.currentUser?.uid

        if (userId != null) {
            val userRef = FirebaseDatabase.getInstance().getReference("User").child(userId)
            userRef.get().addOnSuccessListener { snapshot ->
                if (snapshot.exists()) {
                    val ime = snapshot.child("ime").getValue(String::class.java) ?: "Nepoznato ime"
                    val username = snapshot.child("username").getValue(String::class.java) ?: "Nepoznato korisničko ime"
                    val role = snapshot.child("role").getValue(String::class.java) ?: "user"
                    welcomeText.text = "Zdravo, $ime ($username)!"

                    if (role == "admin") {
                        adminButton.visibility = View.VISIBLE
                    }
                } else {
                    welcomeText.text = "Korisnik ne postoji u bazi"
                }
            }.addOnFailureListener {
                welcomeText.text = "Greška pri učitavanju korisnika"
            }
        }

        adminButton.setOnClickListener {
            startActivity(Intent(this, AdminActivity::class.java))
        }

        logoutButton.setOnClickListener {
            auth.signOut()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}
