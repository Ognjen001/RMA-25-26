package com.example.firebaseapp

import android.content.DialogInterface
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*

class AdminActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: UsersAdapter
    private lateinit var db: DatabaseReference
    private var userList = ArrayList<User>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        recyclerView = findViewById(R.id.usersRecycler)
        recyclerView.layoutManager = LinearLayoutManager(this)

        adapter = UsersAdapter(userList,
            onEdit = { user -> showEditDialog(user) },
            onDelete = { user -> deleteUser(user) }
        )
        recyclerView.adapter = adapter

        db = FirebaseDatabase.getInstance().reference.child("User")

        loadUsers()
    }

    private fun loadUsers() {
        db.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                userList.clear()
                for (data in snapshot.children) {
                    val user = data.getValue(User::class.java)
                    user?.let { userList.add(it) }
                }
                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun deleteUser(user: User) {
        user.uid?.let {
            db.child(it).removeValue()
            Toast.makeText(this, "Korisnik obrisan", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showEditDialog(user: User) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_edit_user, null)
        val imeEt = dialogView.findViewById<EditText>(R.id.editIme)
        val usernameEt = dialogView.findViewById<EditText>(R.id.editUsername)
        val roleSpinner = dialogView.findViewById<Spinner>(R.id.roleSpinner)

        imeEt.setText(user.ime)
        usernameEt.setText(user.username)

        // Spinner setup
        val roles = listOf("user", "admin")
        val adapterSpinner = ArrayAdapter(this, android.R.layout.simple_spinner_item, roles)
        adapterSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        roleSpinner.adapter = adapterSpinner

        val currentIndex = roles.indexOf(user.role ?: "user")
        if (currentIndex >= 0) roleSpinner.setSelection(currentIndex)

        AlertDialog.Builder(this)
            .setTitle("Izmena korisnika")
            .setView(dialogView)
            .setPositiveButton("Sačuvaj") { _: DialogInterface, _: Int ->
                val updatedUser = user.copy(
                    ime = imeEt.text.toString(),
                    username = usernameEt.text.toString(),
                    role = roleSpinner.selectedItem.toString()
                )

                db.child(user.uid!!).setValue(updatedUser)
                Toast.makeText(this, "Izmenjeno", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Otkaži", null)
            .show()
    }
}
