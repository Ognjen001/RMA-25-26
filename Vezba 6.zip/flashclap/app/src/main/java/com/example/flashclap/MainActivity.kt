package com.example.flashclap

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private var isFlashOn = false
    private var isClapMode = false
    private var cameraManager: android.hardware.camera2.CameraManager? = null
    private var cameraId: String? = null

    private lateinit var btnFlash: Button
    private lateinit var btnClapMode: Button
    private lateinit var txtStatus: TextView

    // Permissions launcher
    private val requestPermissionsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { perms ->
            val cameraGranted = perms[Manifest.permission.CAMERA] ?: false
            val audioGranted = perms[Manifest.permission.RECORD_AUDIO] ?: false

            if (!cameraGranted) {
                Toast.makeText(this, "Dozvola za kameru odbijena!", Toast.LENGTH_SHORT).show()
            }
            if (!audioGranted) {
                Toast.makeText(this, "Dozvola za mikrofon odbijena!", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnFlash = findViewById(R.id.btnFlash)
        btnClapMode = findViewById(R.id.btnClapMode)
        txtStatus = findViewById(R.id.txtStatus)

        requestNeededPermissions()

        cameraManager = getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
        cameraId = cameraManager!!.cameraIdList[0]

        btnFlash.setOnClickListener { toggleFlash() }
        btnClapMode.setOnClickListener { toggleClapMode() }
    }

    private fun requestNeededPermissions() {
        val permissions = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        )
        requestPermissionsLauncher.launch(permissions)
    }

    // ------------------------
    // BLIC FUNKCIJA
    // ------------------------
    @SuppressLint("MissingPermission")
    private fun toggleFlash() {
        // Proveri da li uređaj ima blic
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)) {
            Toast.makeText(this, "Uređaj nema blic!", Toast.LENGTH_SHORT).show()
            return
        }

        // Provera dozvole za kameru
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Dozvola za kameru nije data!", Toast.LENGTH_SHORT).show()
            requestPermissionsLauncher.launch(arrayOf(Manifest.permission.CAMERA))
            return
        }

        // Uključi/isključi blic
        isFlashOn = !isFlashOn
        try {
            cameraManager?.setTorchMode(cameraId!!, isFlashOn)
        } catch (e: SecurityException) {
            e.printStackTrace()
            Toast.makeText(this, "Nemamo dozvolu za kameru!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Greška pri kontroli blica", Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------
    // CLAP MODE
    // ------------------------
    private fun toggleClapMode() {
        isClapMode = !isClapMode

        if (isClapMode) {
            txtStatus.text = "Clap Mode je ON"
            startClapListener()
        } else {
            txtStatus.text = "Clap Mode je OFF"
        }
    }

    @SuppressLint("MissingPermission")
    private fun startClapListener() {
        // Provera dozvole za mikrofon
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Dozvola za mikrofon nije data!", Toast.LENGTH_SHORT).show()
            requestPermissionsLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }

        Thread {
            val minBuffer = AudioRecord.getMinBufferSize(
                44100,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )

            val recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                44100,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minBuffer
            )

            val buffer = ShortArray(minBuffer)
            recorder.startRecording()

            while (isClapMode) {
                recorder.read(buffer, 0, buffer.size)

                val amplitude = buffer.maxOrNull()?.toInt() ?: 0

                if (amplitude > 20000) { // prag osetljivosti
                    runOnUiThread {
                        toggleFlash()
                        Toast.makeText(this, "Aplauz detektovan!", Toast.LENGTH_SHORT).show()
                    }
                    Thread.sleep(1500)
                }
            }

            recorder.stop()
            recorder.release()
        }.start()
    }
}
